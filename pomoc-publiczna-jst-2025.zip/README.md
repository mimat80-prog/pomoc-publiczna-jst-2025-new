# Pomoc publiczna JST 2025 – prezentacja szkoleniowa

Prezentacja opracowana przez Michała Matrasa:
> Pomoc publiczna udzielana przez jednostki samorządu terytorialnego z uwzględnieniem zmian od 2024 roku.

Repozytorium generuje automatycznie pliki `.pptx` i `.pdf` z wykorzystaniem **Marp CLI** w GitHub Actions.

Po każdym *commicie* GitHub samodzielnie buduje i udostępnia pliki w zakładce **Actions → Artifacts**.
